import Types from "../../ActionConstants";

const initialState = {
    unsuitableInfo: {
        loading: false,
        data: {
            bnum: '',
            btitle:'',
            bwriter:'',
            bcontent:''
        }
    },
    prescribeInfo: {
        loading: false,
        data: {
            bnum: '',
            prescribeCode: '',
            visitCode: '',
            inspectionCode: '',
            statusCode: '',
            prescribeContents: '',
            prescribeDt: '',
            doctorId: ''
        }
    }
}

const reducer = (state = initialState, { type, payload }) => {
    switch (type) {
        case Types.GET_SAMPLE:
            return {
                ...state,
                unsuitableInfo: {
                    ...state.unsuitableInfo,
                    loading:true,
                }
            }

        case Types.GET_SAMPLE_SUCCESS:
            return {
                ...state,
                unsuitableInfo: {
                    ...state.unsuitableInfo,
                    loading: false,
                    data: payload
                }
            }

        case Types.GET_SAMPLE_FAILURE:
            return {
                ...state,
                unsuitableInfo: {
                    ...state.unsuitableInfo,
                    loading: false,
                    data: {
                        error: payload
                    }
                }
            }

        case Types.GET_PRESCRIBE:
            return{
                ...state,
                prescribeInfo: {
                    ...state.prescribeInfo,
                    loading:true,
                }
            }
        
        case Types.GET_PRESCRIBE_SUCCESS:
            return {
                ...state,
                prescribeInfo: {
                    ...state.prescribeInfo,
                    loading: false,
                    data: payload
                }
            }
        
        case Types.GET_PRESCRIBE_FAILURE:
            return {
                ...state,
                prescribeInfo: {
                    ...state.prescribeInfo,
                    loading: false,
                    data: {
                        error: payload
                    }
                }
            }

        default:
            return state;
    }
}

export default reducer;